// server/controllers/markerController.js
import Marker, { find } from '../models/Marker';

export async function addMarker(req, res) {
  const { userId, lat, lng } = req.body;

  if (!userId || !lat || !lng) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const newMarker = new Marker({ userId, lat, lng });
    const marker = await newMarker.save();
    res.status(201).json(marker);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server error' });
  }
}

export async function getMarkers(req, res) {
  try {
    const markers = await find({ userId: req.params.userId });
    res.json(markers);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server error' });
  }
}
