// server/index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const carRoutes = require('./routes/carRoutes');

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

// Use the correct carRoutes
app.use('/api/cars', carRoutes);

const mongoURI = 'mongodb+srv://aronacosta173:QK8yqNDyQlCdVJ2k@cluster0.rgn5c.mongodb.net/cardata?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('MongoDB connected');
})
.catch((err) => {
  console.log('MongoDB connection error:', err);
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
