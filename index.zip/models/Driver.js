// // server/models/Rider.js
// import { Schema, model } from 'mongoose';

// const DriverSchema = new Schema({
//   email: {
//     type: String,
//     required: true,
//     unique: true
//   },
//   password: {
//     type: String,
//     required: true
//   }
// });

// export default model('Driver', DriverSchema);
