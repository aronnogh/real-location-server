import { Schema, model } from 'mongoose';

const tripSchema = new Schema({
  truck: { type: Schema.Types.ObjectId, ref: 'Truck', required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  revenue: { type: Number, required: true },
});

const TripModel = model('Trip', tripSchema);
export default TripModel;
